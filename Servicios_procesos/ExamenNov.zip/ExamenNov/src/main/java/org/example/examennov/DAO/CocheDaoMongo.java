package org.example.examennov.DAO;

public interface CocheDaoMongo {
}
