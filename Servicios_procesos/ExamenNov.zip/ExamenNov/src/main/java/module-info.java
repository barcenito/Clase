module org.example.examennov {
	requires javafx.controls;
	requires javafx.fxml;

	requires org.controlsfx.controls;
	requires com.dlsc.formsfx;
	requires org.hibernate.orm.core;
	requires mongodb.driver;
	requires com.fasterxml.jackson.databind;
	requires java.sql;
	requires java.persistence;
	requires java.naming;

	opens org.example.examennov to javafx.fxml;
	opens org.example.examennov.Controller to javafx.fxml;
	opens org.example.examennov.DAO to javafx.fxml;
	opens org.example.examennov.Model to javafx.fxml, org.hibernate.orm.core;
	opens org.example.examennov.utils to javafx.fxml;
	exports org.example.examennov;
}